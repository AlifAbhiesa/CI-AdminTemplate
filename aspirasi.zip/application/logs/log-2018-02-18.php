<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-02-18 01:17:41 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-18 01:17:56 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-18 01:17:58 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-18 01:18:04 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-18 01:18:04 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-18 01:18:04 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-18 01:18:13 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-18 01:21:21 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-18 01:21:22 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-18 01:21:22 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-18 01:21:22 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-18 01:25:03 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-18 02:04:27 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-18 02:04:27 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-18 02:04:27 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-18 02:04:29 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-18 02:04:47 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-18 02:04:47 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-18 02:04:47 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-18 02:04:48 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-18 02:04:49 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-18 02:04:49 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-18 02:04:49 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-18 02:04:51 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-18 02:05:10 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-18 02:05:10 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-18 02:05:10 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-18 02:05:12 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-18 02:05:24 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-18 02:05:25 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-18 02:05:25 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-18 02:05:36 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-18 02:06:40 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-18 02:06:40 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-18 02:06:40 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-18 02:06:52 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-18 02:06:52 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-18 02:06:52 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-18 02:09:17 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-18 02:09:17 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-18 02:09:17 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-18 02:15:10 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-18 02:15:10 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-18 02:15:10 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-18 02:17:41 --> 404 Page Not Found: admin/Adminlte/Member
ERROR - 2018-02-18 02:17:46 --> 404 Page Not Found: admin/Member/index
ERROR - 2018-02-18 02:17:59 --> Severity: Notice --> Undefined index: is_admin C:\xampp\htdocs\aspirasi\application\views\admin\member\index.php 28
ERROR - 2018-02-18 02:17:59 --> Severity: Notice --> Undefined index: is_admin C:\xampp\htdocs\aspirasi\application\views\admin\member\index.php 28
ERROR - 2018-02-18 02:21:57 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-18 02:22:07 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-18 02:22:08 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-18 02:22:08 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-18 02:22:26 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-18 02:22:26 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-18 02:22:26 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-18 02:22:29 --> 404 Page Not Found: admin/Adminlte/Member
ERROR - 2018-02-18 02:32:27 --> Severity: Notice --> Undefined index: nama_anggota C:\xampp\htdocs\aspirasi\application\views\admin\member\detail.php 10
ERROR - 2018-02-18 02:32:27 --> Severity: Notice --> Undefined index: jabatan_anggota C:\xampp\htdocs\aspirasi\application\views\admin\member\detail.php 11
ERROR - 2018-02-18 02:32:27 --> Severity: Notice --> Undefined index: nrp_anggota C:\xampp\htdocs\aspirasi\application\views\admin\member\detail.php 14
ERROR - 2018-02-18 02:32:27 --> Severity: Notice --> Undefined index: nrp_anggota C:\xampp\htdocs\aspirasi\application\views\admin\member\detail.php 21
ERROR - 2018-02-18 02:32:27 --> Severity: Notice --> Undefined index: angkatan_anggota C:\xampp\htdocs\aspirasi\application\views\admin\member\detail.php 34
ERROR - 2018-02-18 02:32:27 --> Severity: Notice --> Undefined index: alamat_anggota C:\xampp\htdocs\aspirasi\application\views\admin\member\detail.php 52
ERROR - 2018-02-18 02:32:27 --> Severity: Notice --> Undefined index: skill C:\xampp\htdocs\aspirasi\application\views\admin\member\detail.php 59
ERROR - 2018-02-18 02:32:27 --> Severity: Notice --> Undefined index: notes C:\xampp\htdocs\aspirasi\application\views\admin\member\detail.php 65
ERROR - 2018-02-18 02:32:27 --> Severity: Notice --> Undefined index: instagram C:\xampp\htdocs\aspirasi\application\views\admin\member\detail.php 71
ERROR - 2018-02-18 02:32:28 --> 404 Page Not Found: admin/Member/dist
ERROR - 2018-02-18 02:35:35 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\aspirasi\application\views\admin\member\detail.php 20
ERROR - 2018-02-18 02:35:35 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\aspirasi\application\views\admin\member\detail.php 25
ERROR - 2018-02-18 02:35:35 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\aspirasi\application\views\admin\member\detail.php 33
ERROR - 2018-02-18 02:35:35 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\aspirasi\application\views\admin\member\detail.php 41
ERROR - 2018-02-18 02:36:17 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\aspirasi\application\views\admin\member\detail.php 20
ERROR - 2018-02-18 02:36:17 --> Severity: Notice --> Undefined index: skill C:\xampp\htdocs\aspirasi\application\views\admin\member\detail.php 25
ERROR - 2018-02-18 02:36:17 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\aspirasi\application\views\admin\member\detail.php 33
ERROR - 2018-02-18 02:36:17 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\aspirasi\application\views\admin\member\detail.php 41
ERROR - 2018-02-18 02:37:10 --> Severity: Notice --> Undefined index: id_about C:\xampp\htdocs\aspirasi\application\views\admin\member\detail.php 20
ERROR - 2018-02-18 02:37:10 --> Severity: Notice --> Undefined index: skill C:\xampp\htdocs\aspirasi\application\views\admin\member\detail.php 25
ERROR - 2018-02-18 02:37:10 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\aspirasi\application\views\admin\member\detail.php 33
ERROR - 2018-02-18 02:37:10 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\aspirasi\application\views\admin\member\detail.php 41
ERROR - 2018-02-18 02:37:37 --> Severity: Notice --> Undefined index: id_anggota C:\xampp\htdocs\aspirasi\application\views\admin\member\detail.php 1
ERROR - 2018-02-18 02:38:24 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'by nrp_anggota ASC' at line 1 - Invalid query: Select * from tbl_anggota, tbl_about where tbl_anggota.id_anggota = tbl_about.id_anggotaorder by nrp_anggota ASC
ERROR - 2018-02-18 02:38:34 --> Severity: Notice --> Undefined index: id_anggota C:\xampp\htdocs\aspirasi\application\views\admin\member\detail.php 1
ERROR - 2018-02-18 02:39:04 --> Severity: Notice --> Undefined index: id_anggota C:\xampp\htdocs\aspirasi\application\views\admin\member\detail.php 1
ERROR - 2018-02-18 02:39:45 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\aspirasi\application\views\admin\member\detail.php 1
ERROR - 2018-02-18 02:40:01 --> Severity: Notice --> Undefined index: id_anggota C:\xampp\htdocs\aspirasi\application\views\admin\member\detail.php 1
ERROR - 2018-02-18 02:41:00 --> Severity: error --> Exception: Call to undefined method Member_model::get_user_by_id() C:\xampp\htdocs\aspirasi\application\controllers\admin\Member.php 51
ERROR - 2018-02-18 02:41:20 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\aspirasi\application\views\admin\users\user_edit.php 20
ERROR - 2018-02-18 02:41:20 --> Severity: Notice --> Undefined index: firstname C:\xampp\htdocs\aspirasi\application\views\admin\users\user_edit.php 25
ERROR - 2018-02-18 02:41:20 --> Severity: Notice --> Undefined index: lastname C:\xampp\htdocs\aspirasi\application\views\admin\users\user_edit.php 33
ERROR - 2018-02-18 02:41:20 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\aspirasi\application\views\admin\users\user_edit.php 41
ERROR - 2018-02-18 02:41:20 --> Severity: Notice --> Undefined index: mobile_no C:\xampp\htdocs\aspirasi\application\views\admin\users\user_edit.php 48
ERROR - 2018-02-18 02:41:20 --> Severity: Notice --> Undefined index: is_admin C:\xampp\htdocs\aspirasi\application\views\admin\users\user_edit.php 57
ERROR - 2018-02-18 02:41:20 --> Severity: Notice --> Undefined index: is_admin C:\xampp\htdocs\aspirasi\application\views\admin\users\user_edit.php 58
ERROR - 2018-02-18 02:41:42 --> Severity: Notice --> Undefined index: id_anggota C:\xampp\htdocs\aspirasi\application\views\admin\member\detail.php 1
ERROR - 2018-02-18 02:41:55 --> Severity: Notice --> Undefined index: id_anggota C:\xampp\htdocs\aspirasi\application\views\admin\member\detail.php 1
ERROR - 2018-02-18 02:42:28 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\aspirasi\application\views\admin\member\detail.php 1
ERROR - 2018-02-18 02:43:06 --> Severity: Notice --> Undefined index: nama_anggota C:\xampp\htdocs\aspirasi\application\views\admin\member\detail.php 1
ERROR - 2018-02-18 02:44:56 --> Severity: Notice --> Undefined index: nama_anggota C:\xampp\htdocs\aspirasi\application\views\admin\member\detail.php 10
ERROR - 2018-02-18 02:44:56 --> Severity: Notice --> Undefined index: jabatan_anggota C:\xampp\htdocs\aspirasi\application\views\admin\member\detail.php 11
ERROR - 2018-02-18 02:44:56 --> Severity: Notice --> Undefined index: nrp_anggota C:\xampp\htdocs\aspirasi\application\views\admin\member\detail.php 14
ERROR - 2018-02-18 02:44:56 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\aspirasi\application\views\admin\member\detail.php 21
ERROR - 2018-02-18 02:44:56 --> Severity: Notice --> Undefined index: angkatan_anggota C:\xampp\htdocs\aspirasi\application\views\admin\member\detail.php 34
ERROR - 2018-02-18 02:44:56 --> Severity: Notice --> Undefined variable: all_profile C:\xampp\htdocs\aspirasi\application\views\admin\member\detail.php 46
ERROR - 2018-02-18 02:44:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\aspirasi\application\views\admin\member\detail.php 46
ERROR - 2018-02-18 02:44:57 --> 404 Page Not Found: admin/Member/dist
ERROR - 2018-02-18 02:45:57 --> Severity: Notice --> Undefined index: nama_anggota C:\xampp\htdocs\aspirasi\application\views\admin\member\detail.php 1
ERROR - 2018-02-18 02:48:36 --> Severity: error --> Exception: Function name must be a string C:\xampp\htdocs\aspirasi\application\views\admin\member\detail.php 1
ERROR - 2018-02-18 02:48:56 --> Severity: Notice --> Undefined index: nama_anggota C:\xampp\htdocs\aspirasi\application\views\admin\member\detail.php 1
ERROR - 2018-02-18 02:50:51 --> Severity: Notice --> Undefined property: Member::$user_model C:\xampp\htdocs\aspirasi\application\controllers\admin\Member.php 52
ERROR - 2018-02-18 02:50:51 --> Severity: error --> Exception: Call to a member function get_user_by_id() on null C:\xampp\htdocs\aspirasi\application\controllers\admin\Member.php 52
ERROR - 2018-02-18 02:51:16 --> Severity: error --> Exception: Call to undefined method Member_model::get_user_by_id() C:\xampp\htdocs\aspirasi\application\controllers\admin\Member.php 52
ERROR - 2018-02-18 02:51:35 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\aspirasi\application\views\admin\users\user_edit.php 20
ERROR - 2018-02-18 02:51:35 --> Severity: Notice --> Undefined index: firstname C:\xampp\htdocs\aspirasi\application\views\admin\users\user_edit.php 25
ERROR - 2018-02-18 02:51:35 --> Severity: Notice --> Undefined index: lastname C:\xampp\htdocs\aspirasi\application\views\admin\users\user_edit.php 33
ERROR - 2018-02-18 02:51:35 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\aspirasi\application\views\admin\users\user_edit.php 41
ERROR - 2018-02-18 02:51:35 --> Severity: Notice --> Undefined index: mobile_no C:\xampp\htdocs\aspirasi\application\views\admin\users\user_edit.php 48
ERROR - 2018-02-18 02:51:35 --> Severity: Notice --> Undefined index: is_admin C:\xampp\htdocs\aspirasi\application\views\admin\users\user_edit.php 57
ERROR - 2018-02-18 02:51:35 --> Severity: Notice --> Undefined index: is_admin C:\xampp\htdocs\aspirasi\application\views\admin\users\user_edit.php 58
ERROR - 2018-02-18 02:51:58 --> Severity: Notice --> Undefined index: id_about C:\xampp\htdocs\aspirasi\application\views\admin\settings\index.php 20
ERROR - 2018-02-18 02:51:58 --> Severity: Notice --> Undefined index: skill C:\xampp\htdocs\aspirasi\application\views\admin\settings\index.php 25
ERROR - 2018-02-18 02:51:58 --> Severity: Notice --> Undefined index: notes C:\xampp\htdocs\aspirasi\application\views\admin\settings\index.php 33
ERROR - 2018-02-18 02:51:58 --> Severity: Notice --> Undefined index: instagram C:\xampp\htdocs\aspirasi\application\views\admin\settings\index.php 41
ERROR - 2018-02-18 02:53:09 --> Severity: Notice --> Undefined index: id_about C:\xampp\htdocs\aspirasi\application\views\admin\settings\index.php 20
ERROR - 2018-02-18 02:53:09 --> Severity: Notice --> Undefined index: skill C:\xampp\htdocs\aspirasi\application\views\admin\settings\index.php 25
ERROR - 2018-02-18 02:53:09 --> Severity: Notice --> Undefined index: notes C:\xampp\htdocs\aspirasi\application\views\admin\settings\index.php 33
ERROR - 2018-02-18 02:53:09 --> Severity: Notice --> Undefined index: instagram C:\xampp\htdocs\aspirasi\application\views\admin\settings\index.php 41
ERROR - 2018-02-18 02:54:17 --> Severity: Notice --> Undefined index: nama_anggota C:\xampp\htdocs\aspirasi\application\controllers\admin\Member.php 53
ERROR - 2018-02-18 02:54:30 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\aspirasi\application\controllers\admin\Member.php 53
ERROR - 2018-02-18 02:54:48 --> Severity: Notice --> Undefined index: nama_anggota C:\xampp\htdocs\aspirasi\application\controllers\admin\Member.php 53
ERROR - 2018-02-18 02:54:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\aspirasi\application\controllers\admin\Member.php 53
ERROR - 2018-02-18 02:55:07 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\aspirasi\application\controllers\admin\Member.php 53
ERROR - 2018-02-18 02:55:08 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\aspirasi\application\controllers\admin\Member.php 53
ERROR - 2018-02-18 02:55:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\aspirasi\application\controllers\admin\Member.php 53
ERROR - 2018-02-18 02:55:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\aspirasi\application\controllers\admin\Member.php 53
ERROR - 2018-02-18 02:55:34 --> Severity: Notice --> Undefined index: id_about C:\xampp\htdocs\aspirasi\application\views\admin\settings\index.php 20
ERROR - 2018-02-18 02:55:34 --> Severity: Notice --> Undefined index: skill C:\xampp\htdocs\aspirasi\application\views\admin\settings\index.php 25
ERROR - 2018-02-18 02:55:34 --> Severity: Notice --> Undefined index: notes C:\xampp\htdocs\aspirasi\application\views\admin\settings\index.php 33
ERROR - 2018-02-18 02:55:34 --> Severity: Notice --> Undefined index: instagram C:\xampp\htdocs\aspirasi\application\views\admin\settings\index.php 41
ERROR - 2018-02-18 02:56:25 --> Severity: Notice --> Undefined index: nama_anggota C:\xampp\htdocs\aspirasi\application\views\admin\member\detail.php 1
ERROR - 2018-02-18 02:56:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\aspirasi\application\views\admin\member\detail.php 1
ERROR - 2018-02-18 02:59:07 --> 404 Page Not Found: admin/Member/dist
ERROR - 2018-02-18 03:00:15 --> 404 Page Not Found: admin/Member/dist
ERROR - 2018-02-18 03:00:31 --> 404 Page Not Found: admin/Member/dist
ERROR - 2018-02-18 03:00:40 --> 404 Page Not Found: admin/Member/dist
ERROR - 2018-02-18 03:01:08 --> 404 Page Not Found: admin/Member/dist
ERROR - 2018-02-18 03:01:14 --> 404 Page Not Found: admin/Member/dist
ERROR - 2018-02-18 03:02:58 --> 404 Page Not Found: admin/Member/dist
ERROR - 2018-02-18 03:13:29 --> 404 Page Not Found: admin/Member/dist
ERROR - 2018-02-18 03:14:23 --> 404 Page Not Found: admin/Member/dist
ERROR - 2018-02-18 03:15:44 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-18 03:18:34 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-18 03:19:21 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-18 03:19:35 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-18 03:34:20 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-18 03:34:35 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-18 04:01:39 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-18 04:02:39 --> 404 Page Not Found: admin/Member/dist
ERROR - 2018-02-18 04:42:44 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-18 11:58:25 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-18 11:59:02 --> 404 Page Not Found: admin/Member/dist
ERROR - 2018-02-18 11:59:10 --> 404 Page Not Found: admin/Member/dist
ERROR - 2018-02-18 11:59:24 --> 404 Page Not Found: admin/Member/dist
ERROR - 2018-02-18 11:59:44 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-18 12:01:12 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-18 12:02:35 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-18 12:05:41 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-18 12:05:53 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-18 12:06:14 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-18 12:06:17 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-18 12:06:31 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-18 12:06:33 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-18 12:06:37 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-18 20:04:29 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-18 20:04:29 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-18 20:22:49 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-18 20:23:49 --> 404 Page Not Found: Dist/img
