<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-02-19 07:10:49 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-19 07:18:11 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-19 07:18:26 --> 404 Page Not Found: admin/Member/dist
ERROR - 2018-02-19 07:28:32 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-19 07:29:22 --> 404 Page Not Found: admin/Member/dist
ERROR - 2018-02-19 07:49:03 --> Severity: Notice --> Undefined index: tanggal C:\xampp\htdocs\aspirasi\application\controllers\admin\Aspirasi.php 20
ERROR - 2018-02-19 07:49:03 --> Severity: Notice --> Undefined index: updated C:\xampp\htdocs\aspirasi\application\controllers\admin\Aspirasi.php 23
ERROR - 2018-02-19 07:49:03 --> Query error: Unknown column 'user' in 'field list' - Invalid query: INSERT INTO `tbl_aspirasi` (`id_aspirasi`, `user`, `date`, `updated`, `judul`, `aspirasi`, `privasi`, `kategori`, `flag`) VALUES (NULL, '1', '2018-02-19 07:49:03 UTC', '2018-02-19 07:49:03 UTC', 'Judul Aspirasi 6', 'Lorem', 'BP', 'public', '1')
ERROR - 2018-02-19 07:50:12 --> Query error: Unknown column 'user' in 'field list' - Invalid query: INSERT INTO `tbl_aspirasi` (`id_aspirasi`, `user`, `date`, `updated`, `judul`, `aspirasi`, `privasi`, `kategori`, `flag`) VALUES (NULL, '1', '2018-02-19 07:50:12 UTC', '2018-02-19 07:50:12 UTC', 'Judul Aspirasi 6', 'lorem', 'BPA', 'public', '1')
ERROR - 2018-02-19 09:38:17 --> 404 Page Not Found: admin/Adminlte/form
ERROR - 2018-02-19 09:38:47 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-19 09:38:54 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-19 09:38:54 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-19 09:41:31 --> Severity: Notice --> Undefined index: kategori C:\xampp\htdocs\aspirasi\application\controllers\admin\Aspirasi.php 23
ERROR - 2018-02-19 09:47:35 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-19 09:47:35 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-19 14:43:32 --> Query error: Unknown column 'id' in 'where clause' - Invalid query: UPDATE `tbl_anggota` SET `password` = '4913a9178621eadcdf191db17915fbcb'
WHERE `id` = '1'
ERROR - 2018-02-19 14:44:11 --> Query error: Unknown column 'password' in 'field list' - Invalid query: UPDATE `tbl_anggota` SET `password` = '4913a9178621eadcdf191db17915fbcb'
WHERE `id_anggota` = '1'
ERROR - 2018-02-19 14:53:29 --> Severity: Notice --> Undefined property: Aspirasi::$user_model C:\xampp\htdocs\aspirasi\application\controllers\admin\Aspirasi.php 74
ERROR - 2018-02-19 14:53:29 --> Severity: error --> Exception: Call to a member function get_user_by_id() on null C:\xampp\htdocs\aspirasi\application\controllers\admin\Aspirasi.php 74
ERROR - 2018-02-19 14:54:29 --> Severity: Notice --> Undefined property: Aspirasi::$user_model C:\xampp\htdocs\aspirasi\application\controllers\admin\Aspirasi.php 74
ERROR - 2018-02-19 14:54:29 --> Severity: error --> Exception: Call to a member function get_user_by_id() on null C:\xampp\htdocs\aspirasi\application\controllers\admin\Aspirasi.php 74
ERROR - 2018-02-19 14:54:55 --> Severity: Notice --> Undefined property: Aspirasi::$user_model C:\xampp\htdocs\aspirasi\application\controllers\admin\Aspirasi.php 74
ERROR - 2018-02-19 14:54:55 --> Severity: error --> Exception: Call to a member function get_user_by_id() on null C:\xampp\htdocs\aspirasi\application\controllers\admin\Aspirasi.php 74
ERROR - 2018-02-19 14:55:16 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\aspirasi\application\views\admin\users\user_edit.php 20
ERROR - 2018-02-19 14:55:16 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\aspirasi\application\views\admin\users\user_edit.php 25
ERROR - 2018-02-19 14:55:16 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\aspirasi\application\views\admin\users\user_edit.php 33
ERROR - 2018-02-19 14:55:16 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\aspirasi\application\views\admin\users\user_edit.php 41
ERROR - 2018-02-19 14:55:16 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\aspirasi\application\views\admin\users\user_edit.php 48
ERROR - 2018-02-19 14:55:16 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\aspirasi\application\views\admin\users\user_edit.php 57
ERROR - 2018-02-19 14:55:16 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\aspirasi\application\views\admin\users\user_edit.php 58
ERROR - 2018-02-19 15:10:13 --> Severity: error --> Exception: syntax error, unexpected '=>' (T_DOUBLE_ARROW), expecting ')' C:\xampp\htdocs\aspirasi\application\models\admin\Aspirasi_model.php 20
ERROR - 2018-02-19 15:19:01 --> Severity: Notice --> Undefined index: id_aspirasi C:\xampp\htdocs\aspirasi\application\controllers\admin\Aspirasi.php 57
ERROR - 2018-02-19 15:19:24 --> Severity: Notice --> Undefined index: id_aspirasi C:\xampp\htdocs\aspirasi\application\controllers\admin\Aspirasi.php 57
ERROR - 2018-02-19 15:19:36 --> Severity: Notice --> Undefined index: id_aspirasi C:\xampp\htdocs\aspirasi\application\controllers\admin\Aspirasi.php 57
ERROR - 2018-02-19 15:19:52 --> Severity: Notice --> Undefined index: id_aspirasi C:\xampp\htdocs\aspirasi\application\controllers\admin\Aspirasi.php 57
ERROR - 2018-02-19 15:24:31 --> Severity: error --> Exception: Call to a member function row_array() on boolean C:\xampp\htdocs\aspirasi\application\models\admin\Aspirasi_model.php 35
