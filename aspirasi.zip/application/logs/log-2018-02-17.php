<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-02-17 06:35:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'db_username'@'localhost' (using password: YES) C:\xampp\htdocs\aspirasi\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2018-02-17 06:35:09 --> Unable to connect to the database
ERROR - 2018-02-17 06:37:14 --> Query error: Table 'ci_adminlte.ci_users' doesn't exist - Invalid query: SELECT *
FROM `ci_users`
WHERE `email` = 'admin@admin.com'
ERROR - 2018-02-17 06:39:10 --> 404 Page Not Found: admin/Adminlte/compose.html
ERROR - 2018-02-17 06:40:41 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-17 06:41:29 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-17 06:41:29 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-17 06:41:29 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-17 09:20:01 --> Severity: error --> Exception: C:\xampp\htdocs\aspirasi\application\models/admin/Aspirasi_model.php exists, but doesn't declare class Aspirasi_model C:\xampp\htdocs\aspirasi\system\core\Loader.php 336
ERROR - 2018-02-17 09:20:17 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\aspirasi\application\views\admin\aspirasi\index.php 23
ERROR - 2018-02-17 09:20:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\aspirasi\application\views\admin\aspirasi\index.php 23
ERROR - 2018-02-17 09:21:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '.`id`' at line 2 - Invalid query: SELECT *
FROM `tbl_aspirasi LEFT JOIN ci_user ON tbl_aspirasi`.`user =` `ci_user`.`id`
ERROR - 2018-02-17 09:22:22 --> Severity: error --> Exception: syntax error, unexpected ')' C:\xampp\htdocs\aspirasi\application\models\admin\Aspirasi_model.php 10
ERROR - 2018-02-17 09:22:34 --> Severity: error --> Exception: Call to a member function result_array() on string C:\xampp\htdocs\aspirasi\application\models\admin\Aspirasi_model.php 11
ERROR - 2018-02-17 09:22:59 --> Severity: error --> Exception: Call to a member function result_array() on string C:\xampp\htdocs\aspirasi\application\models\admin\Aspirasi_model.php 11
ERROR - 2018-02-17 09:24:29 --> Query error: Table 'ci_adminlte.officer' doesn't exist - Invalid query: SELECT * FROM officer ORDER BY officerid ASC
ERROR - 2018-02-17 09:24:44 --> Query error: Table 'ci_adminlte.ci_user' doesn't exist - Invalid query: Select * from tbl_aspirasi LEFT JOIN ci_user ON tbl_aspirasi.user = ci_user.id
ERROR - 2018-02-17 10:37:49 --> Severity: error --> Exception: Cannot use object of type CI_Session as array C:\xampp\htdocs\aspirasi\application\views\admin\aspirasi\index.php 27
ERROR - 2018-02-17 10:38:57 --> Severity: error --> Exception: Cannot use object of type CI_Session as array C:\xampp\htdocs\aspirasi\application\views\admin\aspirasi\index.php 27
ERROR - 2018-02-17 11:10:43 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO), expecting ';' C:\xampp\htdocs\aspirasi\application\controllers\admin\Aspirasi.php 19
ERROR - 2018-02-17 11:11:58 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) C:\xampp\htdocs\aspirasi\application\controllers\admin\Aspirasi.php 19
ERROR - 2018-02-17 11:33:45 --> Severity: Notice --> Undefined index: id_user C:\xampp\htdocs\aspirasi\application\controllers\admin\Aspirasi.php 19
ERROR - 2018-02-17 11:33:45 --> Severity: Notice --> Undefined index: tanggal C:\xampp\htdocs\aspirasi\application\controllers\admin\Aspirasi.php 20
ERROR - 2018-02-17 11:34:32 --> Severity: Notice --> Undefined index: id_user C:\xampp\htdocs\aspirasi\application\controllers\admin\Aspirasi.php 19
ERROR - 2018-02-17 11:34:32 --> Severity: Notice --> Undefined index: tanggal C:\xampp\htdocs\aspirasi\application\controllers\admin\Aspirasi.php 20
ERROR - 2018-02-17 11:35:25 --> Query error: Unknown column 'id_user' in 'field list' - Invalid query: INSERT INTO `tbl_aspirasi` (`id_aspirasi`, `id_user`, `date`, `judul`, `aspirasi`) VALUES (NULL, '3', '02/13/2018', 'judul', 'isi')
ERROR - 2018-02-17 11:43:37 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`ci_adminlte`.`tbl_aspirasi`, CONSTRAINT `FK_tbl_aspirasi_ci_users` FOREIGN KEY (`user`) REFERENCES `ci_users` (`id`) ON UPDATE CASCADE) - Invalid query: DELETE FROM `ci_users`
WHERE `id` = '11'
ERROR - 2018-02-17 11:53:12 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\aspirasi\application\views\admin\aspirasi\index.php 71
ERROR - 2018-02-17 11:53:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\aspirasi\application\views\admin\aspirasi\index.php 71
ERROR - 2018-02-17 11:54:42 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\aspirasi\application\views\admin\aspirasi\index.php 23
ERROR - 2018-02-17 11:54:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\aspirasi\application\views\admin\aspirasi\index.php 23
ERROR - 2018-02-17 11:55:30 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\aspirasi\application\views\admin\aspirasi\index.php 72
ERROR - 2018-02-17 11:55:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\aspirasi\application\views\admin\aspirasi\index.php 72
ERROR - 2018-02-17 11:57:20 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\aspirasi\application\views\admin\aspirasi\index.php 74
ERROR - 2018-02-17 11:57:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\aspirasi\application\views\admin\aspirasi\index.php 74
ERROR - 2018-02-17 12:50:51 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-17 12:53:38 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-17 13:06:23 --> Query error: Unknown column 'nrp' in 'where clause' - Invalid query: SELECT *
FROM `tbl_anggota`
WHERE `nrp` = '152015077'
ERROR - 2018-02-17 13:07:09 --> Severity: Notice --> Undefined index: password C:\xampp\htdocs\aspirasi\application\models\admin\Auth_model.php 12
ERROR - 2018-02-17 13:09:00 --> Severity: Notice --> Undefined index: password C:\xampp\htdocs\aspirasi\application\models\admin\Auth_model.php 12
ERROR - 2018-02-17 13:11:11 --> Severity: Notice --> Undefined index: password C:\xampp\htdocs\aspirasi\application\models\admin\Auth_model.php 12
ERROR - 2018-02-17 13:18:55 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file C:\xampp\htdocs\aspirasi\application\models\admin\Auth_model.php 17
ERROR - 2018-02-17 13:19:02 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file C:\xampp\htdocs\aspirasi\application\models\admin\Auth_model.php 17
ERROR - 2018-02-17 13:20:36 --> Severity: Notice --> Undefined index: nrp_anggota C:\xampp\htdocs\aspirasi\application\models\admin\Auth_model.php 5
ERROR - 2018-02-17 13:24:59 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\aspirasi\application\models\admin\Auth_model.php 5
ERROR - 2018-02-17 13:26:15 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\aspirasi\application\controllers\admin\Auth.php 38
ERROR - 2018-02-17 13:26:26 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\aspirasi\application\controllers\admin\Auth.php 38
ERROR - 2018-02-17 13:26:34 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\aspirasi\application\controllers\admin\Auth.php 38
ERROR - 2018-02-17 13:26:46 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\aspirasi\application\controllers\admin\Auth.php 38
ERROR - 2018-02-17 13:31:24 --> Severity: error --> Exception: Call to a member function row_array() on string C:\xampp\htdocs\aspirasi\application\models\admin\Auth_model.php 8
ERROR - 2018-02-17 13:32:23 --> Query error: Unknown column 'password' in 'where clause' - Invalid query: select * from tbl_anggota where nrp_anggota = 152015077 and password = a63803002366dd761244102e062b5971
ERROR - 2018-02-17 13:33:25 --> Query error: Unknown column 'password' in 'where clause' - Invalid query: select * from tbl_anggota where nrp_anggota = 152015077 and password = a63803002366dd761244102e062b5971
ERROR - 2018-02-17 13:33:45 --> Query error: Unknown column 'a63803002366dd761244102e062b5971' in 'where clause' - Invalid query: select * from tbl_anggota where nrp_anggota = 152015077 and password_anggota = a63803002366dd761244102e062b5971
ERROR - 2018-02-17 13:41:43 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-17 14:46:54 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-17 14:46:54 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-17 14:47:41 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-17 14:47:41 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-17 14:48:35 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-17 14:48:35 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-17 14:58:51 --> 404 Page Not Found: admin/Layout/fixed
ERROR - 2018-02-17 14:58:55 --> 404 Page Not Found: admin/Layout/collapsed_sidebar
ERROR - 2018-02-17 14:58:58 --> 404 Page Not Found: admin/Layout/top_nav
ERROR - 2018-02-17 15:11:35 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-17 15:11:54 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-17 15:11:55 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-17 15:11:56 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-17 15:11:58 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-17 15:12:10 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-17 15:12:31 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-17 15:12:52 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-17 15:17:09 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-17 15:17:09 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-17 15:18:26 --> 404 Page Not Found: admin/Adminlte/Aspirasi
ERROR - 2018-02-17 15:18:34 --> Query error: Unknown column 'tbl_aspirasi.user' in 'on clause' - Invalid query: Select * from tbl_aspirasi LEFT JOIN ci_users ON tbl_aspirasi.user = ci_users.id
ERROR - 2018-02-17 15:19:15 --> Query error: Unknown column 'tbl_anggota.id' in 'on clause' - Invalid query: Select * from tbl_aspirasi LEFT JOIN tbl_anggota ON tbl_aspirasi.id_anggota = tbl_anggota.id
ERROR - 2018-02-17 15:31:01 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-17 15:32:05 --> 404 Page Not Found: admin/Adminlte/Aspirasi
ERROR - 2018-02-17 15:40:58 --> Query error: Unknown column 'tbl_aspiras.id_anggota' in 'on clause' - Invalid query: Select * from tbl_aspirasi LEFT JOIN tbl_anggota ON tbl_aspirasi.id_anggota = tbl_anggota.id_anggota and tbl_aspiras.id_anggota = 1;
ERROR - 2018-02-17 15:43:10 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-17 15:43:10 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-17 15:43:12 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-17 15:43:12 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-17 15:43:12 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-17 15:43:14 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-17 15:43:14 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-17 15:43:41 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-17 15:43:42 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-17 15:46:17 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-17 15:55:58 --> Severity: Notice --> Undefined index: nrp C:\xampp\htdocs\aspirasi\application\views\admin\timeline\index.php 19
ERROR - 2018-02-17 15:55:58 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\aspirasi\application\views\admin\timeline\index.php 21
ERROR - 2018-02-17 15:55:58 --> Severity: Notice --> Undefined index: nrp C:\xampp\htdocs\aspirasi\application\views\admin\timeline\index.php 19
ERROR - 2018-02-17 15:55:58 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\aspirasi\application\views\admin\timeline\index.php 21
ERROR - 2018-02-17 15:55:58 --> Severity: Notice --> Undefined index: nrp C:\xampp\htdocs\aspirasi\application\views\admin\timeline\index.php 19
ERROR - 2018-02-17 15:55:58 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\aspirasi\application\views\admin\timeline\index.php 21
ERROR - 2018-02-17 15:56:14 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\aspirasi\application\views\admin\timeline\index.php 21
ERROR - 2018-02-17 15:56:14 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\aspirasi\application\views\admin\timeline\index.php 21
ERROR - 2018-02-17 15:56:14 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\aspirasi\application\views\admin\timeline\index.php 21
ERROR - 2018-02-17 15:56:14 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-17 15:56:14 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-17 15:56:15 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-17 15:56:15 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-17 15:56:23 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-17 15:56:23 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-17 15:56:23 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-17 15:56:23 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-17 15:59:49 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-17 16:00:32 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-17 16:00:55 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-17 16:01:11 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-17 16:15:37 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-17 16:15:41 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-17 16:15:41 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-17 16:15:51 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-17 16:15:52 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-17 16:15:52 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-17 16:16:36 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-17 16:16:36 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-17 16:23:26 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-17 16:23:49 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-17 16:37:47 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-17 16:37:47 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-17 16:37:48 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-17 16:37:53 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-17 16:37:53 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-17 16:39:43 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-17 16:39:43 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-17 16:39:43 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-17 16:43:42 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-17 16:43:42 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-17 16:43:42 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-17 16:43:42 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-17 16:51:37 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-17 16:51:37 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-17 16:51:37 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-17 16:52:16 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-17 16:52:16 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-17 16:52:16 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-17 16:52:24 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-17 16:52:24 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-17 16:52:24 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-17 16:52:28 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-17 16:52:55 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-17 16:52:55 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-17 16:52:55 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-17 16:55:11 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-17 16:55:11 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-17 16:55:11 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-17 16:55:11 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-17 16:55:55 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-17 16:55:55 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-17 16:55:55 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-17 17:01:55 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-17 17:01:55 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-17 17:01:55 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-17 17:08:33 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-17 17:08:33 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-17 17:08:33 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-17 17:08:33 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-17 17:08:38 --> Severity: Notice --> Undefined variable: iduser C:\xampp\htdocs\aspirasi\application\models\admin\Profile_model.php 9
ERROR - 2018-02-17 17:08:38 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 1 - Invalid query: select * from tbl_anggota,tbl_about where tbl_anggota.id_anggota=tbl_about.id_anggota and tbl_anggota.id_anggota = 
ERROR - 2018-02-17 17:08:52 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-17 17:10:32 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-17 17:11:22 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-17 17:13:24 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-17 17:13:35 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-17 17:13:56 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-17 17:15:03 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-17 17:15:35 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-17 17:15:35 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-17 17:15:35 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-17 17:15:35 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-17 17:28:24 --> Severity: error --> Exception: Function name must be a string C:\xampp\htdocs\aspirasi\application\views\admin\profile\index.php 53
ERROR - 2018-02-17 17:28:26 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-17 17:30:25 --> Severity: error --> Exception: syntax error, unexpected 'as' (T_AS) C:\xampp\htdocs\aspirasi\application\views\admin\profile\index.php 51
ERROR - 2018-02-17 17:30:40 --> Severity: Notice --> Undefined index: alamat C:\xampp\htdocs\aspirasi\application\views\admin\profile\index.php 53
ERROR - 2018-02-17 17:30:41 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-17 17:30:49 --> Severity: Notice --> Undefined index: alamat_anggota C:\xampp\htdocs\aspirasi\application\views\admin\profile\index.php 53
ERROR - 2018-02-17 17:30:49 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-17 17:31:14 --> Severity: Notice --> Undefined index: alamat_anggota C:\xampp\htdocs\aspirasi\application\views\admin\profile\index.php 53
ERROR - 2018-02-17 17:31:16 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-17 17:32:27 --> Severity: Notice --> Undefined index: nrp_anggota C:\xampp\htdocs\aspirasi\application\views\admin\profile\index.php 53
ERROR - 2018-02-17 17:32:27 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-17 17:33:41 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-17 17:34:00 --> Severity: error --> Exception: syntax error, unexpected 'as' (T_AS) C:\xampp\htdocs\aspirasi\application\views\admin\profile\index.php 48
ERROR - 2018-02-17 17:35:16 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-17 17:35:54 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-17 17:37:07 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-17 17:39:54 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-17 17:40:58 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-17 17:41:14 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-17 17:42:55 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-17 17:43:02 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-17 17:44:50 --> 404 Page Not Found: admin/Settings/index
ERROR - 2018-02-17 17:56:12 --> 404 Page Not Found: admin/Settings/index
ERROR - 2018-02-17 17:58:22 --> Severity: error --> Exception: C:\xampp\htdocs\aspirasi\application\models/admin/Settings_model.php exists, but doesn't declare class Settings_model C:\xampp\htdocs\aspirasi\system\core\Loader.php 336
ERROR - 2018-02-17 17:58:35 --> Severity: error --> Exception: Call to undefined method Settings_model::get_all_users() C:\xampp\htdocs\aspirasi\application\controllers\admin\Settings.php 12
ERROR - 2018-02-17 17:59:29 --> Severity: Notice --> Undefined property: Settings::$user_model C:\xampp\htdocs\aspirasi\application\controllers\admin\Settings.php 88
ERROR - 2018-02-17 17:59:29 --> Severity: error --> Exception: Call to a member function get_user_by_id() on null C:\xampp\htdocs\aspirasi\application\controllers\admin\Settings.php 88
ERROR - 2018-02-17 18:00:00 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\aspirasi\application\views\admin\users\user_edit.php 20
ERROR - 2018-02-17 18:00:00 --> Severity: Notice --> Undefined index: firstname C:\xampp\htdocs\aspirasi\application\views\admin\users\user_edit.php 25
ERROR - 2018-02-17 18:00:00 --> Severity: Notice --> Undefined index: lastname C:\xampp\htdocs\aspirasi\application\views\admin\users\user_edit.php 33
ERROR - 2018-02-17 18:00:00 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\aspirasi\application\views\admin\users\user_edit.php 41
ERROR - 2018-02-17 18:00:00 --> Severity: Notice --> Undefined index: mobile_no C:\xampp\htdocs\aspirasi\application\views\admin\users\user_edit.php 48
ERROR - 2018-02-17 18:00:00 --> Severity: Notice --> Undefined index: is_admin C:\xampp\htdocs\aspirasi\application\views\admin\users\user_edit.php 57
ERROR - 2018-02-17 18:00:00 --> Severity: Notice --> Undefined index: is_admin C:\xampp\htdocs\aspirasi\application\views\admin\users\user_edit.php 58
ERROR - 2018-02-17 18:01:01 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\aspirasi\application\views\admin\users\user_edit.php 20
ERROR - 2018-02-17 18:01:01 --> Severity: Notice --> Undefined index: firstname C:\xampp\htdocs\aspirasi\application\views\admin\users\user_edit.php 25
ERROR - 2018-02-17 18:01:01 --> Severity: Notice --> Undefined index: lastname C:\xampp\htdocs\aspirasi\application\views\admin\users\user_edit.php 33
ERROR - 2018-02-17 18:01:01 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\aspirasi\application\views\admin\users\user_edit.php 41
ERROR - 2018-02-17 18:01:01 --> Severity: Notice --> Undefined index: mobile_no C:\xampp\htdocs\aspirasi\application\views\admin\users\user_edit.php 48
ERROR - 2018-02-17 18:01:01 --> Severity: Notice --> Undefined index: is_admin C:\xampp\htdocs\aspirasi\application\views\admin\users\user_edit.php 57
ERROR - 2018-02-17 18:01:01 --> Severity: Notice --> Undefined index: is_admin C:\xampp\htdocs\aspirasi\application\views\admin\users\user_edit.php 58
ERROR - 2018-02-17 18:01:51 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\aspirasi\application\views\admin\settings\index.php 20
ERROR - 2018-02-17 18:07:49 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE), expecting ',' or ';' C:\xampp\htdocs\aspirasi\application\views\admin\include\sidebar.php 85
ERROR - 2018-02-17 18:08:22 --> 404 Page Not Found: admin/Settings/1
ERROR - 2018-02-17 18:21:11 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\aspirasi\application\controllers\admin\Settings.php 85
ERROR - 2018-02-17 18:21:39 --> Severity: Notice --> Undefined property: Settings::$user_model C:\xampp\htdocs\aspirasi\application\controllers\admin\Settings.php 71
ERROR - 2018-02-17 18:21:39 --> Severity: error --> Exception: Call to a member function edit_user() on null C:\xampp\htdocs\aspirasi\application\controllers\admin\Settings.php 71
ERROR - 2018-02-17 18:22:31 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-17 18:24:38 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-17 18:25:02 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-17 18:25:50 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-17 18:26:45 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-17 18:27:08 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-17 18:27:33 --> 404 Page Not Found: Public/dist
ERROR - 2018-02-17 18:27:36 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-17 18:28:41 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-17 18:28:49 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-17 18:32:52 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-17 18:36:22 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-17 18:49:22 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-17 18:49:50 --> 404 Page Not Found: Dist/img
ERROR - 2018-02-17 18:49:53 --> 404 Page Not Found: Dist/img
