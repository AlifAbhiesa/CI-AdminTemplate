<section class="content">
  <div class="row">
    <div class="col-md-12">
      <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title">Edit Aspirasi</h3>
        </div>
        <!-- /.box-header -->
        <!-- form start -->
        <div class="box-body my-form-body">
         
           
            <?php echo form_open(base_url('admin/aspirasi/edit/'.$aspirasi['id_aspirasi']), 'class="form-horizontal"' )?> 
              <div class="form-group">
                <label for="firstname" class="col-sm-2 control-label">Judul</label>

                <div class="col-sm-9">
                  <input type="text" name="judul" value="<?= $aspirasi['judul']; ?>" class="form-control" id="firstname" placeholder="">
                </div>
              </div>
            
            
             <div class="form-group">
                <label class="col-sm-2 control-label">Aspirasi</label>
                <div class="col-sm-9">
                    <textarea type="text" name="aspirasi" class="form-control" id="firstname" placeholder=""><?= $aspirasi['aspirasi']; ?></textarea>
                </div>
              </div>
            
            
           
                <div class="form-group">
                    <label class="col-sm-2 control-label">Kategori</label>
                    <div class="col-sm-9">
                        <select name="kategori" class="form-control select2" style="width: 100%;">
                            <option value="BPA" selected="selected">BPA</option>
                            <option value="BP">BP</option>
                            <option value="Proker">Proker</option>
                        </select>
                    </div>
                </div>
            
            
            
                <div class="form-group">
                    <label class="col-sm-2 control-label">Privasi</label>
                    <div class="col-sm-9">
                        <select name="privasi" class="form-control select2" style="width: 100%;">
                            <option value="Public" selected="selected">Public</option>
                            <option value="Private">Private</option>
                        </select>
                    </div>
                </div>
          
              <div class="form-group">
                <div class="col-md-11">
                    <input type="text" hidden="true" value="<?= $aspirasi['id_aspirasi']; ?>">
                  <input type="submit" name="submit" value="Update" class="btn btn-info pull-right">
                </div>
              </div>
            <?php echo form_close(); ?>
          </div>
          <!-- /.box-body -->
      </div>
    </div>
  </div>  

</section> 