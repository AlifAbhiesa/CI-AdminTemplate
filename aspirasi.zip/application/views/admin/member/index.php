 <!-- Datatable style -->
<link rel="stylesheet" href="<?= base_url() ?>public/plugins/datatables/dataTables.bootstrap.css">  

   
    <div class="box-header">
      <h3 class="box-title">List Member</h3>
    </div>
    <!-- /.box-header -->
    <div class="box-body table-responsive">
      <table id="example1" class="table table-bordered table-striped ">
         

        <thead>
        <tr>
          <th>Nrp</th>
          <th>Nama</th>
         
          <th class="text-center">Option</th>
        </tr>
        </thead>
        <tbody>
          <?php foreach($all_member as $row): ?>
          <tr>
            <td><?= $row['nrp_anggota']; ?></td>
            <td><?= $row['nama_anggota']; ?></td>
            <td class="text-center"><a href="<?= base_url('admin/Member/Detail/'.$row['id_anggota']); ?>" class="btn btn-info btn-flat">Detail</a></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
       
      </table>
    </div>
    <!-- /.box-body -->
  
  <!-- /.box -->


<!-- DataTables -->
<script src="<?= base_url() ?>public/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?= base_url() ?>public/plugins/datatables/dataTables.bootstrap.min.js"></script>
<script>
  $(function () {
    $("#example1").DataTable();
  });
    
 $('#tanggal').datepicker({
      autoclose: true
    });
    
    $('#updtanggal').datepicker({
      autoclose: true
    });
</script> 
<script>
$("#view_users").addClass('active');
</script>        

