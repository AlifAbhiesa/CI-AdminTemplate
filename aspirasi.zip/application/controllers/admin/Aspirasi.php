<?php
	defined('BASEPATH') OR exit('No direct script access allowed');

	class Aspirasi extends MY_Controller {

		public function __construct(){
			parent::__construct();
			$this->load->model('admin/Aspirasi_model');
		}

		public function index(){
			$data['all_aspirasi'] =  $this->Aspirasi_model->get_all_aspirasi();
			$data['view'] = 'admin/aspirasi/index';
			$this->load->view('admin/layout', $data);
		}
		
		public function add(){
            
            $id_user = $_POST['id_user'];         
            $judul = $_POST['judul'];
            $aspirasi = $_POST['aspirasi'];
            $privasi = $_POST['privasi'];
            $kategori = $_POST['kategori'];
            $flag = '1';
            
        
					$data = array(
                        'id_aspirasi' => null,
						'id_anggota' => $id_user,
						'date' => date('Y-m-d h:i:s'),
						'updated' => date('Y-m-d h:i:s'),
						'judul' => $judul,
						'aspirasi' => $aspirasi,
						'privasi' => $privasi,
						'kategori' => $kategori,
						'flag' => $flag,
					);
					$result = $this->Aspirasi_model->add_aspirasi($data);
					if($result){
						$this->session->set_flashdata('msg', 'Record is Updated Successfully!');
						redirect(base_url('admin/Aspirasi'));
					}
			
		}

		public function edit($id = 0){
			if($this->input->post('submit')){
				

				if ($this->form_validation->run() == TRUE) {
					$data['aspirasi'] = $this->Aspirasi_model->get_aspirasi_by_id($id);
					$data['view'] = 'admin/aspirasi/edit_aspirasi';
					$this->load->view('admin/layout', $data);
				}
				else{
                    
                    $id_aspirasi = $_POST['id_aspirasi'];
                    $judul = $_POST['judul'];
                    $aspirasi = $_POST['aspirasi'];
                    $privasi = $_POST['privasi'];
                    $kategori = $_POST['kategori'];
					$data = array(
						'id_aspirasi' => $id_aspirasi,
						'judul' => $judul,
						'aspirasi' => $aspirasi,
						'privasi' => $privasi,
						'updated' => date('Y-m-d h:i:s'),
						'kategori' => $kategori,
						
					);
					$result = $this->Aspirasi_model->edit_aspirasi($data, $id);
					if($result){
						$this->session->set_flashdata('msg', 'Record is Updated Successfully!');
						redirect(base_url('admin/Aspirasi'));
					}
				}
			}
			else{
				$data['aspirasi'] = $this->Aspirasi_model->get_aspirasi_by_id($id);
				$data['view'] = 'admin/aspirasi/edit_aspirasi';
				$this->load->view('admin/layout', $data);
			}
		}

		public function delete($id = 0){  
            $result = $this->Aspirasi_model->delete_aspirasi($id);
					if($result){
						$this->session->set_flashdata('msg', 'Record is Deleted Successfully!');
			             
					}
            
		}

	}


?>