<?php
	defined('BASEPATH') OR exit('No direct script access allowed');

	class Member extends MY_Controller {

		public function __construct(){
			parent::__construct();
			$this->load->model('admin/Member_model', 'Member_model');
		}

		public function index(){
			$data['all_member'] =  $this->Member_model->get_all_member();
			$data['view'] = 'admin/member/index';
			$this->load->view('admin/layout', $data);
		}
		
		

		public function detail($id = 0){
			$data['user'] = $this->Member_model->get_member_by_id($id);
            $data['view'] = 'admin/member/detail';
            $this->load->view('admin/layout', $data);
		}

		

	}


?>